﻿using System.Collections;
using System.Collections.Generic;
using UnityEngine;
using UnityEngine.Events;

public class ScreenSpaceLocations : MonoBehaviour
{
    private enum ScreenSpaceTarget
    {
        None,
        MousePosition,
        ScreenCenter
    }

    [Header("Stats")]
    [SerializeField] private bool createRayTransformInUpdate;
    [SerializeField] private ScreenSpaceTarget screenTarget = ScreenSpaceTarget.MousePosition;

    [Header("Events")]
    [SerializeField] private UnityEventRaycastDirection onRayTransformCreated;

    private Camera screenCamera;

    void Update()
    {
        if (createRayTransformInUpdate == false)
            return;

        switch (screenTarget)
        {
            case ScreenSpaceTarget.None:
                break;

            case ScreenSpaceTarget.MousePosition:
                CreateRayTransformFromMousePos();
                break;

            case ScreenSpaceTarget.ScreenCenter:
                CreateRayTransformFromScreenCenter();
                break;
        }
    }

    public void CreateRayTransformFromMousePos()
    {
        screenCamera = Camera.main;

        if (screenCamera == null)
            return;

        Vector3 targetPos = screenCamera.ScreenToWorldPoint(new Vector3(Input.mousePosition.x, Input.mousePosition.y, screenCamera.nearClipPlane * 2f));
        CreateRayTransform(targetPos);
    }

    public void CreateRayTransformFromScreenCenter()
    {
        screenCamera = Camera.main;

        if (screenCamera == null)
            return;

        Vector3 targetPos = screenCamera.ScreenToWorldPoint(new Vector3(Screen.width / 2, Screen.height / 2, screenCamera.nearClipPlane * 2f));
        CreateRayTransform(targetPos);
    }

    void CreateRayTransform(Vector3 targetPos)
    {
        Vector3 heading = targetPos - transform.position;
        float distance = heading.magnitude;
        Vector3 direction = heading / distance;

        if (onRayTransformCreated != null)
            onRayTransformCreated.Invoke(new RayTransform(transform.position, direction, distance));
    }
}
