﻿using System.Collections;
using System.Collections.Generic;
using UnityEngine;

public class Target : MonoBehaviour
{
    [Header("Debug")]
    [SerializeField] private bool showGizmos;

    private bool targetHit;

    public void TargetHit()
    {
        targetHit = true;
    }

    void OnDrawGizmos()
    {
        if (Application.isPlaying == false || showGizmos == false)
            return;

        if (targetHit == false)
            Gizmos.color = Color.red;
        else
            Gizmos.color = Color.green;

        Gizmos.DrawSphere(transform.position, 0.4f);
    }
}
