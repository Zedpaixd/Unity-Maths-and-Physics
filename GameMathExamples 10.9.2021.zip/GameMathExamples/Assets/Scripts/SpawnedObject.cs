﻿using System.Collections;
using System.Collections.Generic;
using UnityEngine;
using UnityEngine.Events;

public class SpawnedObject : MonoBehaviour, ISpawnedObject
{
    [SerializeField] private UnityEvent onObjectSpawned;

    void ISpawnedObject.SpawnedObjectInit()
    {
        if (onObjectSpawned != null)
            onObjectSpawned.Invoke();
    }
}
