﻿using System.Collections;
using System.Collections.Generic;
using UnityEngine;
using UnityEngine.Events;

public class ObjectSpaceObject : MonoBehaviour
{
    [Header("Stats")]
    [SerializeField] private bool allowControls;
    [SerializeField] private bool copyRotation;
    [SerializeField] private float movementSpeed = 10f;
    

    [Header("Events")]
    [SerializeField] UnityEvent onEnteringRadius;
    [SerializeField] UnityEvent onExitingRadius;

    Transform otherObject;
    Vector3 positionInOtherSpace;
    private bool inRadius;

	void OnEnable()
    {
        StartCoroutine(CustomUpdate());
    }

    void OnDisable()
    {
        StopAllCoroutines();
    }

    IEnumerator CustomUpdate()
    {
        Vector3 inputVector = Vector3.zero;

        while (true)
        {
            if (otherObject != null)
            {
                #region Movement Input
                if (allowControls == true)
                {
                    if (Input.GetKey(KeyCode.W) == true)
                        inputVector = Vector3.forward * Time.deltaTime * movementSpeed;
                    else if (Input.GetKey(KeyCode.S) == true)
                        inputVector = Vector3.back * Time.deltaTime * movementSpeed;
                    else if (Input.GetKey(KeyCode.D) == true)
                        inputVector = Vector3.right * Time.deltaTime * movementSpeed;
                    else if (Input.GetKey(KeyCode.A) == true)
                        inputVector = Vector3.left * Time.deltaTime * movementSpeed;
                    else
                        inputVector = Vector3.zero;

                    //Add user input to the converted space position
                    positionInOtherSpace += inputVector;
                }
                #endregion

                if (copyRotation == true)
                    transform.rotation = otherObject.rotation;

                //Convert the local space position back to world space and assign it to this object's world space position
                transform.position = otherObject.TransformPoint(positionInOtherSpace);

                yield return null;
            }
            else
                yield return null;
        }
    }

    public void SetInRadius(bool value, ObjectSpaceTrigger trigger)
    {
        if (trigger != null)
        {
            otherObject = trigger.transform;

            //Convert this object's position to a position in local space of the other object
            positionInOtherSpace = otherObject.InverseTransformPoint(transform.position);
        }
        else
            otherObject = null;

        if (value == true && inRadius == false  && onEnteringRadius != null)
            onEnteringRadius.Invoke();

        if (value == false && inRadius == true && onExitingRadius != null)
            onExitingRadius.Invoke();

        inRadius = value;
    }
}
