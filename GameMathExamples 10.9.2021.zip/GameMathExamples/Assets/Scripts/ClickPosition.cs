﻿using System.Collections;
using System.Collections.Generic;
using UnityEngine;
using UnityEngine.Events;


[RequireComponent(typeof(Camera))]
public class ClickPosition : MonoBehaviour
{
    [Header("Stats")]
    [SerializeField] private float rayDistance = 100f;
    [SerializeField] private LayerMask clickRayLayers;

    [Header("Events")]
    [SerializeField] private UnityEventPosition onRayHit;

    private Camera clickCamera;

    void Start()
    {
        clickCamera = GetComponent<Camera>();
    }

    void Update()
    {
        if (Input.GetMouseButtonDown(0))
            ShootRayFromMousePos();
    }

    void ShootRayFromMousePos()
    {
        Ray ray = clickCamera.ScreenPointToRay(Input.mousePosition);
        RaycastHit rayHit;

        if (Physics.Raycast(ray, out rayHit, rayDistance, clickRayLayers, QueryTriggerInteraction.Ignore))
        {
            if (onRayHit != null)
                onRayHit.Invoke(rayHit.point, Quaternion.LookRotation(rayHit.normal));
        }
    }
}
