﻿using System.Collections;
using System.Collections.Generic;
using UnityEngine;

public class UnderstandingCoroutines : MonoBehaviour
{
    [Min(1)] public int targetFrameRate = 60;
    [Min(1)] public int framesBetweenFixedUpdates = 6;

    public GameObject updateObject;
    public GameObject fixedUpdateObject;
    public GameObject coroutineUpdateObject;
    public GameObject coroutineFixedUpdateObject;

    #region Init
    void Start()
    {
        SetFramerate();

        StartCoroutine(MyCustomUpdate());
        StartCoroutine(MyCustomFixedUpdate());
    }

    //Setting target frame rate and fixed delta time
    void SetFramerate()
    {
        Application.targetFrameRate = targetFrameRate;
        Time.fixedDeltaTime = 1f / (targetFrameRate / (float)framesBetweenFixedUpdates);
    }
    #endregion

    #region Updates
    void Update()
    {
        SetFramerate();

        Debug.Log("<color=cyan>This update is called every frame | Frame:" + Time.frameCount + "</color>");

        //Is frame even using modulo operator
        //Only used to show the flicker in the scene
        if (Time.frameCount % 2 == 0)
            StartCoroutine(ToggleObjectForOneFrame(updateObject));
    }
    
    void FixedUpdate()
    {
        Debug.Log("<color=cyan>This fixed update is called every fixed frame-rate frame | Frame:" + Time.frameCount + "</color>");

        StartCoroutine(ToggleObjectForOneFrame(fixedUpdateObject));
    }
    #endregion

    #region Coroutine Updates
    IEnumerator MyCustomUpdate()
    {
        while(true)
        {
            Debug.Log("<color=orange>This coroutine is called every frame | Frame:" + Time.frameCount + "</color>");

            //Is frame even using modulo operator
            //Only used to show the flicker in the scene
            if (Time.frameCount % 2 == 0)
                StartCoroutine(ToggleObjectForOneFrame(coroutineUpdateObject));

            yield return null;
        }
    }

    IEnumerator MyCustomFixedUpdate()
    {
        while (true)
        {
            Debug.Log("<color=orange>This coroutine is called every fixed frame-rate frame | Frame:" + Time.frameCount + "</color>");

            StartCoroutine(ToggleObjectForOneFrame(coroutineFixedUpdateObject));

            yield return new WaitForFixedUpdate();
        }
    }
	#endregion

	#region Flicker Coroutine
	IEnumerator ToggleObjectForOneFrame(GameObject objectToToggle)
    {
        if (objectToToggle == null)
            yield break;

        objectToToggle.SetActive(true);
        yield return null;
        objectToToggle.SetActive(false);
    }
	#endregion
}
