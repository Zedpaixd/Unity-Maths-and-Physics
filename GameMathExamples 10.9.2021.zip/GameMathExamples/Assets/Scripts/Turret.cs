﻿using System.Collections;
using System.Collections.Generic;
using UnityEngine;

public class Turret : MonoBehaviour
{
    [SerializeField] private float projectileForce = 10f; 
    [SerializeField] private float cooldown = 1f;
    [SerializeField] private GameObject projectilePrefab;

    void Start()
    {
        StartCoroutine(TurretLoop());
    }

    IEnumerator TurretLoop()
    {
        while (true)
        {
            SpawnProjectile();
            yield return new WaitForSeconds(cooldown);
        }
    }

    void SpawnProjectile()
    {
        GameObject projectileClone = GameObject.Instantiate(projectilePrefab, transform.position, transform.rotation, null);
        
        if (projectileClone.TryGetComponent<Rigidbody>(out Rigidbody projectileBody))
            projectileBody.AddForce(transform.forward * projectileForce);
    }
}
