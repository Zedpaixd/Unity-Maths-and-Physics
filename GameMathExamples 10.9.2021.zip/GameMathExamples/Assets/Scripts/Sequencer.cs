﻿using System.Collections;
using System.Collections.Generic;
using UnityEngine;
using UnityEngine.Events;

[System.Serializable]
public class SequencerEvent : UnityEvent<int> { }

public class Sequencer : MonoBehaviour
{
    private enum SequenceValue
    {
        ActualIndex,
        IncrementedIndex
    }

    [Header("Stats")]
    [SerializeField][Tooltip("Defines the amount of sequences. -1 Means infinite sequences")][Range(-1, 10)] private int sequences = -1;
    [SerializeField][Range(0f, 10f)] private float sequenceDuration = 1;
    [SerializeField][Space] SequenceValue sequenceValue = SequenceValue.ActualIndex;
    [SerializeField] private bool descending;
    [SerializeField][Tooltip("If the sequencer will be started in the Start() method")] private bool startAutomatically;
    [SerializeField][Min(0)]  private float startDelay = 1f;

    [Header("Debug")]
    [SerializeField]private bool showDebug;

    [SerializeField][Header("Before Start Delay Event")] private UnityEvent beforeSequencerStartDelay;
    public UnityEvent BeforeSequencerStartDelay { get { return beforeSequencerStartDelay; } }

    [SerializeField][Header("Start Event")] private SequencerEvent onSequencerStart;
    public SequencerEvent OnSequencerStart { get { return onSequencerStart; } }

    [SerializeField][Header("Sequence Event")] private SequencerEvent onNewSequence;
    public SequencerEvent OnNewSequence { get { return onNewSequence; } }

    [SerializeField][Header("End Event")] private SequencerEvent onSequencerEnd;
    public SequencerEvent OnSequencerEnd { get { return onSequencerEnd; } }

    private Coroutine sequencerLoop;
    private int currentSequence;
    private int eventSequenceValue;

    void Start()
    {
        if (startAutomatically == true)
            StartSequencer();
    }

    public void StartSequencer()
    {
        if (sequencerLoop != null)
            StopCoroutine(sequencerLoop);

        sequencerLoop = StartCoroutine(SequencerLoop());
    }

    IEnumerator SequencerLoop()
    {
        int target = descending ? -1 : sequences;
        int increment = descending ? -1 : 1;
        currentSequence = descending ? (sequences - 1) : 0;

        if (sequenceValue == SequenceValue.IncrementedIndex)
            eventSequenceValue = currentSequence + 1;
        else
            eventSequenceValue = currentSequence;

        #region Before Start Delay Event
        if (showDebug == true)
            Debug.Log("<color=blue>Sequencer: </color>" + gameObject.name + "<color=blue> | BEFORE START DELAY </color>");

        if (beforeSequencerStartDelay != null)
            beforeSequencerStartDelay.Invoke();
        #endregion

        yield return new WaitForSeconds(startDelay);

        #region Start Event
        if (showDebug == true)
            Debug.Log("<color=blue>Sequencer: </color>" + gameObject.name + "<color=blue> | START </color>");

        if (onSequencerStart != null)
            onSequencerStart.Invoke(eventSequenceValue);
        #endregion

        while (currentSequence != target || sequences == -1)
        {
            #region Sequence Event
            if (showDebug == true)
                Debug.Log("<color=blue>Sequencer: </color>" + gameObject.name + "<color=blue> | Sequence: </color>" + (eventSequenceValue));

            if (onNewSequence != null)
                onNewSequence.Invoke(eventSequenceValue);
            #endregion

            currentSequence += increment;
            eventSequenceValue += increment;
            
            yield return new WaitForSeconds(sequenceDuration);
        }

        #region End Event
        if (showDebug == true)
            Debug.Log("<color=blue>Sequencer: </color>" + gameObject.name + "<color=blue> | END </color>");

        if (onSequencerEnd != null)
            onSequencerEnd.Invoke(eventSequenceValue);
        #endregion
    }
}
