using System.Collections;
using System.Collections.Generic;
using UnityEngine;

public class RayTransform
{
    public Vector3 rayPosition;
    public Vector3 rayDirection;
    public float rayDistance;

    public RayTransform() { }

    public RayTransform(Vector3 pos, Vector3 dir, float dist)
    {
        rayPosition = pos;
        rayDirection = dir;
        rayDistance = dist;
    }
}