using System.Collections;
using System.Collections.Generic;
using UnityEngine;
using UnityEngine.Events;

[System.Serializable] public class UnityEventRaycastDirection : UnityEvent<RayTransform> { }

[System.Serializable] public class UnityEventPosition : UnityEvent<Vector3, Quaternion> { }