using System.Collections;
using System.Collections.Generic;
using UnityEngine;

interface ISpawnedObject
{
    void SpawnedObjectInit();
}