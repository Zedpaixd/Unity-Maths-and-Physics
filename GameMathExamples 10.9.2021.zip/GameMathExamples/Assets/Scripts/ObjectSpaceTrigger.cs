﻿using System.Collections;
using System.Collections.Generic;
using UnityEngine;

[RequireComponent(typeof(Collider))]
public class ObjectSpaceTrigger : MonoBehaviour
{
    void OnTriggerEnter(Collider col)
    {
        if (col.TryGetComponent<ObjectSpaceObject>(out ObjectSpaceObject manipulatedObject))
            manipulatedObject.SetInRadius(true, this);
    }

    void OnTriggerExit(Collider col)
    {
        if (col.TryGetComponent<ObjectSpaceObject>(out ObjectSpaceObject manipulatedObject))
            manipulatedObject.SetInRadius(false, null);
    }
}
