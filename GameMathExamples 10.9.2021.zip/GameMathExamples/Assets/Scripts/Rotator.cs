﻿
using System.Collections;
using System.Collections.Generic;
using UnityEngine;

[ExecuteInEditMode]
public class Rotator : MonoBehaviour
{
    private enum RotatorType
    {
        None,
        RandomRotation,
        RotateAxis,
        RotateAround
    }

    private enum Axis
    {
        X_Axis,
        Y_Axis,
        Z_Axis
    }

    [SerializeField] private RotatorType rotatorType = RotatorType.RandomRotation;
    [SerializeField] [NaughtyAttributes.ShowIf("isRotateAround")] [Space] private bool isWorldSpace;
    [SerializeField] [NaughtyAttributes.ShowIf("isRotateAround")] private Transform rotateAround;
    [SerializeField] [NaughtyAttributes.HideIf(NaughtyAttributes.EConditionOperator.Or, "isNone", "isRandomRotation", "isRotateAxis", "isWorldSpace")] private Vector3 rotateAroundOffset;
    [SerializeField] [NaughtyAttributes.ShowIf(NaughtyAttributes.EConditionOperator.And, "isRotateAround", "isWorldSpace")] private Axis axis;

    [SerializeField] [NaughtyAttributes.HideIf(NaughtyAttributes.EConditionOperator.And, "isRotateAround", "isWorldSpace")] [Space] private float xSpeed = 50f;
    [SerializeField] [NaughtyAttributes.HideIf(NaughtyAttributes.EConditionOperator.And, "isRotateAround", "isWorldSpace")] private float ySpeed = 50f;
    [SerializeField] [NaughtyAttributes.HideIf(NaughtyAttributes.EConditionOperator.And, "isRotateAround", "isWorldSpace")] private float zSpeed = 50f;

    [SerializeField] [NaughtyAttributes.ShowIf(NaughtyAttributes.EConditionOperator.And, "isRotateAround", "isWorldSpace")] [Space] private float speed = 50f;

    [SerializeField] [NaughtyAttributes.ShowIf("isRandomRotation")] [Range(0.01f, 1f)][Space] private float hardness = 0.1f;

    private Vector3 randomRotation;
    private Vector3 toRotation;
    private float averageSpeed;

	#region Editor
	//INSPECTOR
	[SerializeField][HideInInspector] private bool isNone;
    [SerializeField][HideInInspector] private bool isRandomRotation;
    [SerializeField][HideInInspector] private bool isRotateAxis;
    [SerializeField][HideInInspector] private bool isRotateAround;

    //FOR DYNAMIC INSPECTOR
    private void Update()
    {
        if (Application.isPlaying == true)
            return;

        if (rotatorType == RotatorType.None)
            isNone = true;
        else
            isNone = false;

        if (rotatorType == RotatorType.RotateAround)
            isRotateAround = true;
        else
            isRotateAround = false;

        if (rotatorType == RotatorType.RotateAxis)
            isRotateAxis = true;
        else
            isRotateAxis = false;

        if (rotatorType == RotatorType.RandomRotation)
            isRandomRotation = true;
        else
            isRandomRotation = false;
    }
	#endregion

	#region Init
	void Start()
    {
        if (Application.isPlaying == false)
            return;

        switch (rotatorType)
        {
            case RotatorType.None:
                break;
            case RotatorType.RandomRotation:
                StartCoroutine(RandomRotation());
                break;
            case RotatorType.RotateAxis:
                StartCoroutine(RotateAxis());
                break;
            case RotatorType.RotateAround:
                StartCoroutine(RotateAround());
                break;
        }
    }
	#endregion

	#region Random Rotation
	IEnumerator RandomRotation()
    {
        yield return null;

        while (true)
        {
            randomRotation.x = (Mathf.PingPong(Time.time * xSpeed, 360f) - 180f) * 2f;
            randomRotation.y = (Mathf.PingPong(Time.time * ySpeed, 360f) - 180f) * 2f;
            randomRotation.z = (Mathf.PingPong(Time.time * zSpeed, 360f) - 180f) * 2f;

            averageSpeed = (xSpeed + ySpeed + zSpeed) / 3f;

            toRotation = Vector3.Lerp(toRotation, randomRotation, Time.deltaTime * (averageSpeed * hardness));
            transform.eulerAngles = toRotation;

            yield return null;
        }
    }
	#endregion

	#region Axis Rotation
	IEnumerator RotateAxis()
    {
        yield return null;

        while (true)
        {
            transform.localEulerAngles += new Vector3(xSpeed, ySpeed, zSpeed) * Time.deltaTime;
            yield return null;
        }
    }
	#endregion

	#region Round Rotation
	IEnumerator RotateAround()
    {
        yield return null;

        Vector3 convertedPosition = rotateAround.InverseTransformPoint(transform.position);
        
        while (true)
        {
            //LOCAL SPACE
            if (isWorldSpace == false)
            {
                Vector3 rotateAroundSpeeds = new Vector3(xSpeed, ySpeed, zSpeed); //Rotation speeds on axises
                Vector3 offsetPosition = convertedPosition + rotateAroundOffset; //Offset in the space of the rotateAround object

                Vector3 newPosition = Quaternion.Euler(rotateAroundSpeeds * Time.time) * offsetPosition;
                transform.position = rotateAround.TransformPoint(newPosition);
            }
            //WORLD SPACE
            else
            {
                switch (axis)
                {
                    case Axis.X_Axis:
                        transform.RotateAround(rotateAround.position, Vector3.right, Time.deltaTime * speed);
                        break;
                    case Axis.Y_Axis:
                        transform.RotateAround(rotateAround.position, Vector3.up, Time.deltaTime * speed);
                        break;
                    case Axis.Z_Axis:
                        transform.RotateAround(rotateAround.position, Vector3.forward, Time.deltaTime * speed);
                        break;
                }
            }

            yield return null;
        }
    }
	#endregion
}
