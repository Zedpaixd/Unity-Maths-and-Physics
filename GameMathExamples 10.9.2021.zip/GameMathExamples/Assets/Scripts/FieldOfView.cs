﻿using System.Collections;
using System.Collections.Generic;
using UnityEngine;
using UnityEngine.Events;

[ExecuteInEditMode]
[RequireComponent(typeof(SphereCollider))]
public class FieldOfView : MonoBehaviour
{
    [System.Serializable]
    private class TargetCollider
    {
        public Collider collider;
        public bool inFieldOfView;

        public TargetCollider(Collider col)
        {
            collider = col;
        }

        public void SetInFOV(bool value)
        {
            inFieldOfView = value;
        }
    }

    [Header("Stats")]
    [SerializeField] [Range(0f, 180f)] private float horizontalFieldOfView = 120f;
    [SerializeField] [Range(0f, 180f)] private float verticalFieldOfView = 90f;
    [SerializeField] [Range(0f, 10f)] private float range = 5f;
    [SerializeField] [Min(0.01f)] private float updateRate = 0.1f;
    [SerializeField] private string targetTag = "Target";

    [Header("Events")]
    [SerializeField] private UnityEventRaycastDirection onTargetInEnteringFOV;

    [Header("Debug")]
    [SerializeField] private bool showDebug;

    private List<TargetCollider> targetsInRadius = new List<TargetCollider>();
    private SphereCollider sphereCollider;

    #region Init
    void OnEnable()
    {
        if (Application.isPlaying == false)
            return;

        StartCoroutine(UpdateFieldOfView());
    }

    void OnDisable()
    {
        if (Application.isPlaying == false)
            return;

        StopAllCoroutines();
    }
    #endregion

    #region Target Collection
    void OnTriggerEnter(Collider col)
    {
        if (col.gameObject.CompareTag(targetTag) == true)
            AddTargetCollider(targetsInRadius, col);
    }

    void OnTriggerExit(Collider col)
    {
        if (col.gameObject.CompareTag(targetTag) == true)
            RemoveTargetCollider(targetsInRadius, col);
    }

    void AddTargetCollider(List<TargetCollider> collection, Collider collider)
    {
        foreach (TargetCollider target in collection)
        {
            if (target.collider == collider)
                return;
        }

        collection.Add(new TargetCollider(collider));
    }

    void RemoveTargetCollider(List<TargetCollider> collection, Collider collider)
    {
        foreach (TargetCollider target in collection)
        {
            if (target.collider == collider)
            {
                collection.Remove(target);
                return;
            }
        }
    }
    #endregion

    #region Field of View Check
    IEnumerator UpdateFieldOfView()
    {
        while (true)
        {
            for (int i = targetsInRadius.Count - 1; i >= 0; i--)
            {
                //Convert target object's world space position to local space of the FieldOfView object
                Vector3 horizontalTargetPosInLocalSpace = transform.InverseTransformPoint(targetsInRadius[i].collider.transform.position);
                Vector3 verticalTargetPosInLocalSpace = horizontalTargetPosInLocalSpace;

                horizontalTargetPosInLocalSpace.y = 0f;
                verticalTargetPosInLocalSpace.x = 0f;

                //IN HORIZONTAL VIEW
                if (Vector3.Angle(Vector3.forward, horizontalTargetPosInLocalSpace - transform.localPosition) < horizontalFieldOfView * 0.5f)
                {
                    if (showDebug == true)
                        Debug.DrawRay(transform.TransformPoint(horizontalTargetPosInLocalSpace), transform.up * 0.3f, Color.green, updateRate);

                    //IN VERTICAL VIEW & TARGET COMPLETELY IN VIEW
                    if (Vector3.Angle(Vector3.forward, verticalTargetPosInLocalSpace - transform.localPosition) < verticalFieldOfView * 0.5f)
                    {
                        if (showDebug == true)
                        {
                            Debug.DrawRay(transform.TransformPoint(verticalTargetPosInLocalSpace), transform.right * 0.3f, Color.blue, updateRate);
                            Debug.DrawRay(targetsInRadius[i].collider.transform.position, Vector3.up * 3f, Color.green, updateRate);
                        }


                        if (targetsInRadius[i].inFieldOfView == false)
                        {
                            if (showDebug == true)
                                Debug.Log(targetsInRadius[i].collider.gameObject.name + " Entered FOV of " + gameObject.name);

                            Vector3 heading = targetsInRadius[i].collider.transform.position - transform.position;
                            float distance = heading.magnitude;
                            Vector3 direction = heading / distance;

                            if (onTargetInEnteringFOV != null)
                                onTargetInEnteringFOV.Invoke(new RayTransform(transform.position, direction, distance));
                        }

                        targetsInRadius[i].SetInFOV(true);
                    }
                    //NOT IN VERTICAL VIEW
                    else
                    {
                        if (showDebug == true)
                            Debug.DrawRay(transform.TransformPoint(verticalTargetPosInLocalSpace), transform.right * 0.3f, Color.red, updateRate);

                        targetsInRadius[i].SetInFOV(false);
                    }
                }
                //NOT IN HORIZONTAL VIEW
                else
                {
                    if (showDebug == true)
                        Debug.DrawRay(transform.TransformPoint(horizontalTargetPosInLocalSpace), transform.up * 0.3f, Color.red, updateRate);

                    targetsInRadius[i].SetInFOV(false);
                }
            }
            yield return new WaitForSeconds(updateRate);
        }
    }
    #endregion

    #region Editor
    #if UNITY_EDITOR
    void Update()
    {
        if (Application.isPlaying == true)
            return;

        if (sphereCollider == null)
            sphereCollider = GetComponent<SphereCollider>();

        sphereCollider.isTrigger = true;
        sphereCollider.radius = range;
        sphereCollider.center = Vector3.zero;
    }
    #endif
    #endregion

    #region Gizmos
    void OnDrawGizmos()
    {
        if (showDebug == false)
            return;

        Gizmos.matrix = transform.localToWorldMatrix;
        Gizmos.color = Color.green;

        Gizmos.DrawLine(Vector3.zero, Quaternion.AngleAxis(-horizontalFieldOfView * 0.5f, Vector3.up) * Vector3.forward * range);
        Gizmos.DrawLine(Vector3.zero, Quaternion.AngleAxis(horizontalFieldOfView * 0.5f, Vector3.up) * Vector3.forward * range);
        Gizmos.DrawLine(Vector3.zero, Quaternion.AngleAxis(-horizontalFieldOfView * 0.25f, Vector3.up) * Vector3.forward * range);
        Gizmos.DrawLine(Vector3.zero, Quaternion.AngleAxis(horizontalFieldOfView * 0.25f, Vector3.up) * Vector3.forward * range);
        Gizmos.DrawLine(Vector3.zero, Vector3.forward * range);

        Gizmos.color = Color.blue;

        Gizmos.DrawLine(Vector3.zero, Quaternion.AngleAxis(-verticalFieldOfView * 0.5f, Vector3.right) * Vector3.forward * range);
        Gizmos.DrawLine(Vector3.zero, Quaternion.AngleAxis(verticalFieldOfView * 0.5f, Vector3.right) * Vector3.forward * range);
        Gizmos.DrawLine(Vector3.zero, Quaternion.AngleAxis(-verticalFieldOfView * 0.25f, Vector3.right) * Vector3.forward * range);
        Gizmos.DrawLine(Vector3.zero, Quaternion.AngleAxis(verticalFieldOfView * 0.25f, Vector3.right) * Vector3.forward * range);
    }
    #endregion
}
