﻿using System.Collections;
using System.Collections.Generic;
using UnityEngine;
using UnityEditor;

[ExecuteAlways]
public class CopyCameraRotation : MonoBehaviour
{
    Camera cameraToUse;

    void Start()
    {
        if (Application.isPlaying == false)
            cameraToUse = SceneView.lastActiveSceneView.camera;
        else
            cameraToUse = Camera.main;

    }


    void Update()
    {
        if (Application.isPlaying == false)
            cameraToUse = SceneView.lastActiveSceneView.camera;

        transform.rotation = cameraToUse.transform.rotation;
    }
}
