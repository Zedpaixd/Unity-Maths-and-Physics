﻿using System.Collections;
using System.Collections.Generic;
using UnityEngine;
using UnityEngine.Events;

public class Raycaster : MonoBehaviour
{
    private enum PhysicscasttType
    {
        Raycast,
        Spherecast,
        Boxcast
    }

    [Header("Raycast Stats")]
    [SerializeField] private PhysicscasttType physicscastType = PhysicscasttType.Raycast;
    [SerializeField] private float rayDistance = 100f;
    [SerializeField] [Range(-1, 1000)] private int maxRayBounces = -1;
    [SerializeField] private float rayBounceDelay = 0.1f;
    [SerializeField] private LayerMask raycastLayers;
    [SerializeField] private bool startAutomatically;

    [Header("Visuals")]
    [SerializeField] private TrailRenderer raycastTrail;
    [SerializeField] private LineRenderer raycastLine;
    [SerializeField] private float trailLifetime = 0.1f;
    [SerializeField] private Color rayColor = Color.green;

    [Header("Events")]
    [SerializeField] private UnityEventPosition onTrailReachingTarget;
    [SerializeField] private UnityEventPosition onRayHittingTarget;

    [Header("Debug")]
    [SerializeField] private bool showDebug = true;
    [SerializeField] private float debugRayLifetime = 5f;

    private RayTransform gizmoRayTransform;

    #region Init
    void Start()
    {
        if (startAutomatically == true)
            StartRaycastLoop();
    }

    public void StartRaycastLoop(RayTransform rayTransform)
    {
        if (rayTransform != null)
            Raycast(rayTransform);
        else
            StartRaycastLoop();
    }

    public void StartRaycastLoop()
    {
        Raycast(new RayTransform(transform.position, transform.forward, rayDistance));
    }
    #endregion

    #region Raycasting
    void Raycast(RayTransform rayTransform)
    {
        if (raycastLine != null)
        {
            raycastLine.useWorldSpace = true;
            raycastLine.positionCount = 2;
            raycastLine.startColor = rayColor;
            raycastLine.endColor = rayColor;
        }

        if (raycastTrail != null)
        {
            raycastTrail.time = trailLifetime;
            raycastTrail.startColor = rayColor;
            raycastTrail.endColor = rayColor;
        }

        StartCoroutine(RaycastLoop(rayTransform));
    }

    IEnumerator RaycastLoop(RayTransform rayTransform)
    {
        int bounces = 0;

        while (bounces < maxRayBounces || maxRayBounces == -1)
        {
            rayTransform = ShootRay(rayTransform);

            bounces++;
            yield return new WaitForSeconds(rayBounceDelay);
        }
    }

    RayTransform ShootRay(RayTransform currentRayTransform)
    {
        RaycastHit rayHit;

        //RAY HIT
        if (Physics.Raycast(currentRayTransform.rayPosition, currentRayTransform.rayDirection, out rayHit, currentRayTransform.rayDistance, raycastLayers, QueryTriggerInteraction.Ignore))
        {
            if (showDebug == true)
                Debug.DrawRay(currentRayTransform.rayPosition, currentRayTransform.rayDirection * rayHit.distance, rayColor, debugRayLifetime);

            if (onRayHittingTarget != null)
                onRayHittingTarget.Invoke(rayHit.point, Quaternion.LookRotation(rayHit.normal));

            if (rayHit.collider.gameObject.TryGetComponent<Target>(out Target target))
                target.TargetHit();

            //Ray visuals
            StartCoroutine(MoveTrailAlongTheRay(currentRayTransform.rayPosition, rayHit.point, rayHit.normal));
            SetLineRendererPoints(currentRayTransform.rayPosition, rayHit.point);

            //Current ray transform for gizmo
            gizmoRayTransform = new RayTransform(currentRayTransform.rayPosition, currentRayTransform.rayDirection, rayHit.distance);

            //Next ray transform
            return new RayTransform(rayHit.point, Vector3.Reflect(currentRayTransform.rayDirection, rayHit.normal).normalized, currentRayTransform.rayDistance);
        }
        //RAY DIDN'T HIT
        else
        {
            if (showDebug == true)
                Debug.DrawRay(currentRayTransform.rayPosition, currentRayTransform.rayDirection * currentRayTransform.rayDistance, rayColor, debugRayLifetime);

            //Ray visuals
            StartCoroutine(MoveTrailAlongTheRay(currentRayTransform.rayPosition, currentRayTransform.rayPosition + currentRayTransform.rayDirection * currentRayTransform.rayDistance, null));
            SetLineRendererPoints(currentRayTransform.rayPosition, currentRayTransform.rayPosition + currentRayTransform.rayDirection * currentRayTransform.rayDistance);

            //Current ray transform for gizmo
            gizmoRayTransform = new RayTransform(currentRayTransform.rayPosition, currentRayTransform.rayDirection, currentRayTransform.rayDistance);

            //Next ray transform
            return new RayTransform(currentRayTransform.rayPosition + currentRayTransform.rayDirection * currentRayTransform.rayDistance, currentRayTransform.rayDirection, currentRayTransform.rayDistance);
        }
    }
    #endregion

    #region Ray Visuals
    IEnumerator MoveTrailAlongTheRay(Vector3 startPosition, Vector3 toPosition, Vector3? normalDirection)
    {
        if (raycastTrail == null)
            yield break;

        float timer = 0f;

        while (timer < rayBounceDelay)
        {
            raycastTrail.transform.position = Vector3.Lerp(startPosition, toPosition, timer / rayBounceDelay);

            timer += Time.deltaTime;
            yield return null;
        }
        raycastTrail.transform.position = Vector3.Lerp(startPosition, toPosition, 1f);
        

        if (normalDirection != null && onTrailReachingTarget != null)
        {
            onTrailReachingTarget.Invoke(toPosition, Quaternion.LookRotation((Vector3)normalDirection));
        }
    }

    void SetLineRendererPoints(Vector3 startPosition, Vector3 toPosition)
    {
        if (raycastLine == null)
            return;

        raycastLine.SetPosition(0, startPosition);
        raycastLine.SetPosition(1, toPosition);
    }
    #endregion

    #region Gizmos
    void OnDrawGizmos()
    {
        if (Application.isPlaying == false || gizmoRayTransform == null || showDebug == false)
            return;

        //Create a new transform matrix out of the current ray's position, direction and scale (Scale is always 1,1,1)
        Gizmos.matrix = Matrix4x4.TRS(gizmoRayTransform.rayPosition, Quaternion.LookRotation(gizmoRayTransform.rayDirection), Vector3.one);
        Gizmos.color = rayColor;

        switch (physicscastType)
        {
            case PhysicscasttType.Raycast:
                Gizmos.DrawLine(Vector3.zero, (Vector3.forward * gizmoRayTransform.rayDistance * 1f));
                break;

            case PhysicscasttType.Spherecast:
                Gizmos.DrawWireSphere(Vector3.zero, 1f);
                Gizmos.DrawWireSphere(Vector3.forward * gizmoRayTransform.rayDistance * 1f, 1f);

                Gizmos.DrawLine(Vector3.up, (Vector3.forward * gizmoRayTransform.rayDistance * 1f) + Vector3.up);
                Gizmos.DrawLine(Vector3.down, (Vector3.forward * gizmoRayTransform.rayDistance * 1f) + Vector3.down);
                Gizmos.DrawLine(Vector3.right, (Vector3.forward * gizmoRayTransform.rayDistance * 1f) + Vector3.right);
                Gizmos.DrawLine(Vector3.left, (Vector3.forward * gizmoRayTransform.rayDistance * 1f) + Vector3.left);
                break;

            case PhysicscasttType.Boxcast:
                Gizmos.DrawWireCube(Vector3.forward * gizmoRayTransform.rayDistance * 0.5f, new Vector3(1f, 1f, gizmoRayTransform.rayDistance));
                break;
        }
    }
    #endregion
}
