﻿using System.Collections;
using System.Collections.Generic;
using UnityEngine;

public class ObjectSpawner : MonoBehaviour
{
    [SerializeField] private GameObject objectToSpawn;

    public void SpawnObjectToLocation(Vector3 position, Quaternion rotation)
    {
        if (objectToSpawn == null)
            return;

        if (GameObject.Instantiate(objectToSpawn, position, rotation, null).TryGetComponent<ISpawnedObject>(out ISpawnedObject spawnedObject))
            spawnedObject.SpawnedObjectInit();
    }

    public void SpawnObjectToLocation(Transform toTransform)
    {
        if (objectToSpawn == null)
            return;

        if (GameObject.Instantiate(objectToSpawn, toTransform.position, toTransform.rotation, null).TryGetComponent<ISpawnedObject>(out ISpawnedObject spawnedObject))
            spawnedObject.SpawnedObjectInit();
    }
}
