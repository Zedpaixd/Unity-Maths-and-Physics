﻿using System.Collections;
using System.Collections.Generic;
using UnityEngine;

[ExecuteInEditMode]
public class Orbit : MonoBehaviour
{
    [Header("References")]
    [SerializeField] private Transform orbitAround;

    [Header("Orbit")]
    [SerializeField] private Vector3 orbitOrientation;
    [SerializeField] private Vector3 orbitOffset;
    [SerializeField] [Min(0f)] private float orbitDistance = 1f;
    [SerializeField] private float orbitSpeed = 100f;
    [SerializeField] [Range(0f, 360f)] private float orbitStartAngle;

    [Header("Rotation")]
    [SerializeField] private bool rotateSelf;
    [SerializeField] private float rotationSpeed = 100f;

    [Header("Gizmos")]
    [SerializeField] private bool showGizmos = true;
    [SerializeField] [Range(0, 50)] private int orbitResolution = 50;
    [SerializeField] private Color orbitColor = Color.grey;

    Vector3 newDirection;
    Vector3 newPosition;
    Vector3 newRotation;

    #region Editor
    void UpdateStartValues(bool updateOnlyInEditor)
    {
        if (updateOnlyInEditor == true && Application.isPlaying == true)
            return;

        if (orbitAround == null)
            return;

        Quaternion orbitRotation = Quaternion.Euler(orbitOrientation);
        Vector3 orbitUpAxis = orbitRotation * Vector3.up;

        Vector3 startPosition = orbitRotation * Vector3.forward * orbitDistance;
        Quaternion startRotation = Quaternion.AngleAxis(orbitStartAngle, orbitUpAxis);

        newDirection = startRotation * startPosition;
        newPosition = orbitAround.position + (orbitRotation * orbitOffset) + newDirection;
        newRotation = orbitOrientation;

        transform.position = newPosition;
        transform.eulerAngles = newRotation;
    }
    #endregion

    void Start()
    {
        if (orbitAround == null)
            return;

        UpdateStartValues(false);
    }

    void Update()
    {
        UpdateStartValues(true);
        OrbitAround();
        Rotate();
    }

    void OrbitAround()
    {
        if (Application.isPlaying == false || orbitAround == null)
            return;

        Quaternion orbitRotation = Quaternion.Euler(orbitOrientation);
        Vector3 orbitUpAxis = orbitRotation * Vector3.up;

        newDirection = Quaternion.AngleAxis(orbitSpeed * Time.deltaTime, orbitUpAxis) * newDirection;
        newPosition = orbitAround.position + (orbitRotation * orbitOffset) + newDirection;

        transform.position = newPosition;
    }

    void Rotate()
    {
        if (Application.isPlaying == false || rotateSelf == false)
            return;

        Quaternion orbitRotation = Quaternion.Euler(orbitOrientation);
        Vector3 orbitUpAxis = orbitRotation * Vector3.up;

        transform.Rotate(orbitUpAxis, rotationSpeed * Time.deltaTime, Space.World);
    }

    #region Gizmos
    void OnDrawGizmos()
    {
        if (showGizmos == false || orbitAround == null)
            return;

        Gizmos.color = orbitColor;
        Gizmos.matrix = Matrix4x4.TRS(orbitAround.position + (Quaternion.Euler(orbitOrientation) * orbitOffset), Quaternion.Euler(orbitOrientation), new Vector3(1f, 1f, 1f));

        Gizmos.DrawLine(Vector3.down * orbitDistance, Vector3.up * orbitDistance);

        float x;
        float z;
        float previousX = 0;
        float previousZ = 0;

        int segments = orbitResolution;
        float angle = 0f;

        for (int i = 0; i < segments + 1; i++)
        {
            x = Mathf.Sin(Mathf.Deg2Rad * angle) * orbitDistance;
            z = Mathf.Cos(Mathf.Deg2Rad * angle) * orbitDistance;

            if (i != 0)
                Gizmos.DrawLine(new Vector3(previousX, 0f, previousZ), new Vector3(x, 0f, z));

            previousX = x;
            previousZ = z;

            angle += (360f / segments);
        }
    }
    #endregion
}
